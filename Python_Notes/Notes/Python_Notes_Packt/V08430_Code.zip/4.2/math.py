operand1 = 65
operand2 = 83.22

#Addition
print(operand1 + operand2)

#Subtraction
print(operand1 - operand2)

#Multiplication
print(operand1 * operand2)

#Division
print(operand1 / operand2)

##print(9 % 3)
##print(10 % 3)
##print(15 % 6)

print(16 % 2) #even
print(17 % 2) #odd

print(3 ** 3) #Exponent
print(10 ** 2) #Exponent

print(10 // 3) #Floor Division
print(15 // 6) #Floor Division








