name = input("What is your name: ")
print("Welcome to Python", name)
age= input("How old are you?")
print("You are" , age, "years old")
age = int(age)
age = age + 5
print("In five years you will be: ", age)
gpa = input("What is your GPA? ")
print("Your GPA is" , gpa)
gpa = float(gpa)
gpa = gpa + 10




