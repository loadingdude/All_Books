subjects = ("English", "Algebra", "Biology", "Physics", "Computer Science", "Physical Education")
gpas = (3.12, 2.34, 4.0, 3.11, 3.9, 4.55)
addresses = ("123 Main Street" , )

print(subjects)
print(gpas)
