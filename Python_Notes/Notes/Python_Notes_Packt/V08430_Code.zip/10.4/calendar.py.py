import calendar

cal = calendar.month(2009, 10)
print (cal)
