def calculateDogYears(humanYears):
    dogYears = humanYears * 7
    #print("Dog Years:", dogYears)
    return dogYears

def addThese(a,b):
    return a + b

myDogYears = calculateDogYears(9.5)
print("Dog Years", myDogYears)
print("200 + 55=", addThese(200,55))
