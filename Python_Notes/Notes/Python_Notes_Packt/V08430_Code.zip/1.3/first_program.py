#Python Course
#Mark Lassoff
#LearnToProgram.tv

    #Set Variables
    name = "Python for Beginners 2017"
    age = 42
    instructor = "Mark Lassoff"

    #Output
    print(name)
    print(age)
    print(instructor)
