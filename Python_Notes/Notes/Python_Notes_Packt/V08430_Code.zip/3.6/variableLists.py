#List
family = ["Mark", "Brett", "Kerri", "Joan" , "Rick", "Rose"]
print(family)
print(family[3])

numbers = (45,47,265,13)
print(numbers)
#numbers[0] = 15
family[1] = "B-man"
print(family)

#Dictionary
gpas = {"Name": "Mark" , "GPA": 3.55}
print(gpas)

