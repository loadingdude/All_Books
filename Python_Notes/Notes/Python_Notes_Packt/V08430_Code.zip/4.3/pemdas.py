print(5 - 6 * 2)
print((5-6) * 2)
print(3 ** 3 * 5)
print (3 ** (3 * 5))

#PEMDAS
# Parentheses
# Exponents
# Multiplication
# Division
# Addition
# Subtraction


