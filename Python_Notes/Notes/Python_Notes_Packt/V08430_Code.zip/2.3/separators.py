print("Mark","Brett","Joan","Rick", "Kerri", sep="")
print(10,15,20,25,sep="***")
print("Journey",  "REO Speedwagon" , "Foreigner", sep="\n")



