score = 10000
highscore = 90000

if score > highscore:
    print("You have achieved the new high score")
else:
    print("Sorry.  You did not achieve a new high score")
    print("Try again!")

    
