message = "welcome to Python! Thanks for taking my class!"
message2 = "mark"
message3 = "768345345"

print(message.find('for'))
print(message.find('xx'))
if message.find('xx') == -1:
    print("Not found in message")

print(message2.isalpha())
print(message3.isdigit())


