#Integers
score = 1000
time = -42
#Floating Point
gpa = 3.44
battingAverage = 0.375
#Complex or scientific numbers
a = c = 1000.45
a = a -.45
print(a)
print(score, gpa)
print(score * gpa)
print(score + gpa)



