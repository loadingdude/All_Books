# while (true):
    #Do this stuff

x = 0
while (x < 25):
    print("The value of x: ", x)
    x=x+1
    

counter = 100
while (counter > 0):
    print(counter)
    counter = counter - 10
else:
    print("Y is no longer greater than zero")


##y = 1
##while (y > 0):
##    print(y)
##    y = y + 1

