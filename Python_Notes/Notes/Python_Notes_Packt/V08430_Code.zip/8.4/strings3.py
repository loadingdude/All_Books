name= ["Mark", "Adam", "Fred", "Wendy", "Peter", "Marsha"]
j = ","
teams = "Yankees,Mets,Jets,Giants,Knicks,Nets"
message = "Join me for the party tonight"

#print (j.join(name))
#print (len(message))
teamsList= (teams.split(","))
print(teamsList)









