import math

value1 = 89.6
value2 = 176

print(abs(value1 - value2))
print(math.ceil(value1))
print(math.floor(value1))
print(pow(3,4))
print(3**4)


