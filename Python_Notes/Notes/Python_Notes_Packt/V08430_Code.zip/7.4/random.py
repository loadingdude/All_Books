import random

names = ["Fred", "Mary", "Thomas", "Kevin" , "Mike", "June"]
print(random.choice(names))

random.shuffle(names)
print(names)


#print(random.randrange(1,1000,10))


