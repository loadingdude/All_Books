count = 11
x = 0

while x < count:
    y =0
    while y < 11:
        print(y)
        y = y + 1
    x = x + 1

name = ["Mark", "Fred", "Tom", "Craig", "Bobby", "Martha"]

for x in name:
    y = 0
    while y < 5:
        print(x)
        y =y + 1




