file = open("namesList.txt", "a")
name=""
listOfNames=""
while(name != "XXX"):
    name =  input("Name: ")
    if (name != "XXX"):
        listOfNames += name
        listOfNames += ","
print("Saving ", listOfNames)
file.write(listOfNames)
file.close()

