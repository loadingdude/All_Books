try:
    file = open("namesList.txt", "a")
    file.write("EOF")
except IOError:
    print("IO Error")
    file.close()
else:
    print("EOF written succesfully")
    file.close()

