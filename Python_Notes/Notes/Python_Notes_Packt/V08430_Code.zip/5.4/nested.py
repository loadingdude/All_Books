value = 140

if value < 200:
    print ("Value is less than 200")
    if value < 150:
        print("Value is less than 150")
        if value < 100:
            print("Value is less than 100")
            if value == 50:
                print("Value is 50")
else:
    print("value is not less than 200")

                


        
    
