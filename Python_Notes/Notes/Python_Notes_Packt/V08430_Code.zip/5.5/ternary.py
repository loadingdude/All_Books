age = 17
print('Eligible to buy alcohol' if age >= 18 else 'Ineligible to buy alcohol')

citizen = "false"
print('You may vote' if citizen == "true" else 'You may not vote')
