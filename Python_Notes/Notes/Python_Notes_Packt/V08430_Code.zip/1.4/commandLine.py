x = 2015.55
y = 8.79
print("X times Y is:")
print(x*y)