message = "welcome to Python! Thanks for taking my class!"

print(str.capitalize(message))
print(message.center(50 , ' '))
print(message.center(60 , '*'))
print(message.center(80))
print(message.count('s'))
print(message.count('s', 5,15))


