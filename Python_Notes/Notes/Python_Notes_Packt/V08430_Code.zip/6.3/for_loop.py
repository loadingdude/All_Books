courseName = "Python for Beginners 2017"

for letter in courseName:
    print("Current Letter is ", letter)
    if (letter == " "):
        print("This is a space character")

bands = ["Journey", "REO Speedwagon" , "Foreigner", "Heart", "The Cure"]

for x in bands:
    print("Current Band: ", x)






