##name = "Mark Lassoff"
##company = "LearnToProgram.tv"
##age = 42

x = y = z = 5
x = x + 2
print(x,y,z)

age, weight, height = 42, 200, 70
print("Weight:" , weight)
print("Height:" , height)

