#Function definition
def greetingEnglish():
    #This function greets the user in the English language.
    print("Greetings and Salutations")
    return

def greetingSpanish():
    #This function greets in Spanish
    print("Buenos Dias")
    return

#Function Calls
greetingEnglish()
greetingEnglish()
greetingSpanish()

