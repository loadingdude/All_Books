age = 18
citizen = "false"

if(age >=18 and citizen == "true"):
    print("You are legally eligible to vote")
