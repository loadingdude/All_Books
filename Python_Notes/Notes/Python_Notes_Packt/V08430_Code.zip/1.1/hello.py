print("Hello World")
print("Welcome to Python for Beginners 2017!")
print("I'm Mark, your instructor")
