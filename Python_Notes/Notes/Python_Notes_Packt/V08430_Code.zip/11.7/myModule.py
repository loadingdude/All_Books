def greetEnglish():
    return "Greetings!"

def greetSpanish():
    return "Buenos Dias"

def greetFrench():
    return "Bon Jour"

def greetHebrew():
    return "Shalom"

