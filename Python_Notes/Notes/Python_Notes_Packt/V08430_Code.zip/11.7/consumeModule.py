import myModule

print(myModule.greetEnglish())
print(myModule.greetFrench())
